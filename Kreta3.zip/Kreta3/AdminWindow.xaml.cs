using Kreta3.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace Kreta3
{
    public partial class AdminWindow : Window
    {
        private readonly List<Student> _students;

        public AdminWindow(List<Student> students)
        {
            InitializeComponent();
            _students = students ?? new List<Student>();
            dgStudents.ItemsSource = _students;
        }

        private void dgStudents_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = dgStudents.SelectedItem as Student;
            if (selected == null)
            {
                dgSubjects.ItemsSource = null;
                dgGrades.ItemsSource = null;
                return;
            }

            dgSubjects.ItemsSource = selected.Subjects;
            dgGrades.ItemsSource = null;
        }

        private void dgSubjects_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedSubj = dgSubjects.SelectedItem as Subject;
            if (selectedSubj == null)
            {
                dgGrades.ItemsSource = null;
                return;
            }

            dgGrades.ItemsSource = selectedSubj.Grades;
        }

        private void SaveAll_Click(object sender, RoutedEventArgs e)
        {
            File.WriteAllText("students.json", JsonConvert.SerializeObject(_students, Formatting.Indented));
            MessageBox.Show("Adatok mentve!");
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}