﻿using Kreta3.Models;
using Kreta3.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

namespace Kreta3
{
    public partial class MainWindow : Window
    {
        private List<Student> students = new();

        public MainWindow()
        {
            InitializeComponent();
            LoadStudents();
        }

        private void LoadStudents()
        {
            if (File.Exists("students.json"))
            {
                var json = File.ReadAllText("students.json");
                students = JsonConvert.DeserializeObject<List<Student>>(json);
            }
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            var name = txtName.Text.Trim();
            var pass = txtPassword.Password;

            var student = students.FirstOrDefault(s => s.Name == name && s.Password == pass);
            if (student != null)
            {
                var sw = new StudentWindow(student, students);
                sw.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Hibás név vagy jelszó!");
            }
        }
    }
}
