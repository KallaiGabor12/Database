﻿using Kreta3.Models;
using Microsoft.VisualBasic; // InputBox-hoz
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace Kreta3
{
    public partial class StudentWindow : Window
    {
        private Student student;
        private List<Student> allStudents;

        public StudentWindow(Student s, List<Student> all)
        {
            InitializeComponent();
            student = s;
            allStudents = all;
            txtStudentName.Text = $"{s.Name} - Átlag: {s.OverallAverage:F2}" +
                (s.IsAtRisk ? " ⚠️ (Lemorzsolódás veszélye)" : "");

            dgSubjects.ItemsSource = student.Subjects;
            ColorizeAverages();
        }

        private void ColorizeAverages()
        {
            foreach (var item in dgSubjects.Items)
            {
                var subj = item as Subject;
                if (subj != null && subj.Average < 2.0)
                {
                    var row = dgSubjects.ItemContainerGenerator.ContainerFromItem(item) as System.Windows.Controls.DataGridRow;
                    if (row != null)
                        row.Foreground = System.Windows.Media.Brushes.Red;
                }
            }
        }
        private void AddGrade_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new AddGradeWindow(student.Subjects) { Owner = this };
            if (dialog.ShowDialog() == true)
            {
                string subjectName = dialog.SelectedSubject;
                var subject = student.Subjects.FirstOrDefault(s =>
                    s.Name.Equals(subjectName, StringComparison.OrdinalIgnoreCase));

                if (subject == null)
                {
                    subject = new Subject { Name = subjectName };
                    student.Subjects.Add(subject);
                }

                subject.Grades.Add(dialog.NewGrade);

                dgSubjects.ItemsSource = null;
                dgSubjects.ItemsSource = student.Subjects;

                txtStudentName.Text = $"{student.Name} - Átlag: {student.OverallAverage:F2}" +
                    (student.IsAtRisk ? " ⚠️ (Lemorzsolódás veszélye)" : "");

                ColorizeAverages();
            }
        }



        private void Save_Click(object sender, RoutedEventArgs e)
        {
            File.WriteAllText("students.json", JsonConvert.SerializeObject(allStudents, Formatting.Indented));
            MessageBox.Show("Adatok mentve!");
        }
    }
}
