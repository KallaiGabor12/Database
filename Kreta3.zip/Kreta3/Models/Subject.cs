﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kreta3.Models
{
    public class Subject
    {
        public string Name { get; set; }
        public List<Grade> Grades { get; set; } = new();

        public double Average => Grades.Count == 0 ? 0 : Grades.Average(g => g.Value);
    }
}
