﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kreta3.Models
{
    public class Student
    {
        public string Name { get; set; }
        public string Password { get; set; } // egyszerűség kedvéért simán tárolva
        public List<Subject> Subjects { get; set; } = new();

        public double OverallAverage =>
            Subjects.Count == 0 ? 0 : Subjects.Average(s => s.Average);

        public bool IsAtRisk => Subjects.Count(s => s.Average < 1.75) >= 3;
    }
}
