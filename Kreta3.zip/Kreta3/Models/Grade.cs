﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kreta3.Models
{
    public class Grade
    {
        public int Value { get; set; }
        public string Topic { get; set; }
        public string Type { get; set; } // pl. "szóbeli felelet"


    }
}
