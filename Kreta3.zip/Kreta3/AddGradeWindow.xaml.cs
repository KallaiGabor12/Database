﻿using Kreta3.Models;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Kreta3
{
    public partial class AddGradeWindow : Window
    {
        public string SelectedSubject { get; private set; }
        public Grade NewGrade { get; private set; }

        public AddGradeWindow(List<Subject> subjects)
        {
            InitializeComponent();

            cbSubjects.ItemsSource = subjects?.Select(s => s.Name).ToList() ?? new List<string>();

            if (cbSubjects.Items.Count > 0)
            {
                cbSubjects.SelectedIndex = 0;
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            string subjectName = txtNewSubject.Text.Trim();
            if (string.IsNullOrWhiteSpace(subjectName))
            {
                subjectName = cbSubjects.SelectedItem?.ToString();
            }

            if (string.IsNullOrWhiteSpace(subjectName))
            {
                MessageBox.Show("Kérlek válassz vagy adj meg egy tantárgyat!");
                return;
            }

            if (cbGrade.SelectedItem is ComboBoxItem gradeItem)
            {
                if (!int.TryParse(gradeItem.Content.ToString(), out int gradeValue))
                    return;

                NewGrade = new Grade
                {
                    Value = gradeValue,
                    Topic = txtTopic.Text,
                    Type = txtType.Text
                };

                SelectedSubject = subjectName;
                this.DialogResult = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Válassz egy jegyet!");
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
