﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace orak
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Lista.Items.Add("Matematika, 9, Közismereti, 4, 144");
            Lista.Items.Add("Informatika, 9, Szakmai, 3, 108");
            Lista.Items.Add("Informatika, 10, Szakmai, 4, 144");
            Lista.Items.Add("Magyar nyelv, 10, Közismereti, 4, 144");
            Lista.Items.Add("Python, 11, Szakmai, 3, 108");
            Lista.Items.Add("Testnevelés, 11, Közismereti, 3, 108");
            Lista.Items.Add("Adatbázis, 12, Szakmai, 3, 108");
            Lista.Items.Add("Irodalom, 12, Közismereti, 4, 124");
            Lista.Items.Add("C#, 13, Szakmai, 8, 248");
        }

        public int Szorzo(int evfolyam, string tipus)
        {
            if (evfolyam <= 11)
            {
                return 36;
            }
            else if (evfolyam == 12)
            {
                if (targytipusTxt.Text == "Közismereti")
                {
                    return 31;
                }
                else
                {
                    return 36;
                }
            }
            else
            {
                return 31;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Lista.Items.Add($"{tantargyTxt.Text}, {evfolyamTxt.Text}, {targytipusTxt.Text}, {hOraTxt.Text}, {int.Parse(hOraTxt.Text) * Szorzo(int.Parse(evfolyamTxt.Text), targytipusTxt.Text)}");
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            Lista.Items.RemoveAt(Lista.SelectedIndex);
        }

        private void Write_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter sw = new StreamWriter("Orak.txt");
            foreach (var item in Lista.Items)
            {
                string[] adatok = Convert.ToString(item).Split(", ");
                sw.WriteLine($"{adatok[0]};{adatok[1]};{adatok[2]};{adatok[3]};{adatok[4]}");
            }
            sw.Close();
        }

        private void Admin_Click(object sender, RoutedEventArgs e)
        {
            adminLista.Items.Clear();
            int kT9 = 0;
            int szT9 = 0;

            int kO9 = 0;
            int szO9 = 0;

            int kT10 = 0;
            int szT10 = 0;

            int kO10 = 0;
            int szO10 = 0;

            int kT11 = 0;
            int szT11 = 0;

            int kO11 = 0;
            int szO11 = 0;

            int kT12 = 0;
            int szT12 = 0;

            int kO12 = 0;
            int szO12 = 0;

            int szT13 = 0;

            int szO13 = 0;

            foreach (var item in Lista.Items)
            {
                string[] adatok = Convert.ToString(item).Split(", ");
                if (adatok[1] == "9")
                {
                    if (adatok[2] == "Közismereti")
                    {
                        kT9++;
                        kO9 += int.Parse(adatok[4]);
                    }
                    else
                    {
                        szT9++;
                        szO9 += int.Parse(adatok[4]);
                    }
                } else if (adatok[1] == "10")
                {
                    if (adatok[2] == "Közismereti")
                    {
                        kT10++;
                        kO10 += int.Parse(adatok[4]);
                    }
                    else
                    {
                        szT10++;
                        szO10 += int.Parse(adatok[4]);
                    }
                } else if (adatok[1] == "11")
                {
                    if (adatok[2] == "Közismereti")
                    {
                        kT11++;
                        kO11 += int.Parse(adatok[4]);
                    }
                    else
                    {
                        szT11++;
                        szO11 += int.Parse(adatok[4]);
                    }
                } else if (adatok[1] == "12")
                {
                    if (adatok[2] == "Közismereti")
                    {
                        kT12++;
                        kO12 += int.Parse(adatok[4]);
                    }
                    else
                    {
                        szT12++;
                        szO12 += int.Parse(adatok[4]);
                    }
                }
                else
                {
                    szT13++;
                    szO13 += int.Parse(adatok[4]);
                }
            }
            adminLista.Items.Add($"9. évfolyam: K.T.: {kT9} Sz.T.: {szT9} K.Ó.: {kO9} Sz.Ó.: {szO9} Ö.Ó.:{kO9+szO9}");
            adminLista.Items.Add($"10. évfolyam: K.T.: {kT10} Sz.T.: {szT10} K.Ó.: {kO10} Sz.Ó.: {szO10} Ö.Ó.:{kO10 + szO10}");
            adminLista.Items.Add($"11. évfolyam: K.T.: {kT11} Sz.T.: {szT11} K.Ó.: {kO11} Sz.Ó.: {szO11} Ö.Ó.:{kO11 + szO11}");
            adminLista.Items.Add($"12. évfolyam: K.T.: {kT12} Sz.T.: {szT12} K.Ó.: {kO12} Sz.Ó.: {szO12} Ö.Ó.:{kO12 + szO12}");
            adminLista.Items.Add($"13. évfolyam: Sz.T.: {szT13} Sz.Ó.: {szO13}");
        }

        private void Farkas_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != -1)
            {
                string[] adatok = Lista.SelectedItem.ToString().Split(", ");
                farkasLista.Items.Add(adatok[0]);
            }
        }
        private void Gabi_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != -1)
            {
                string[] adatok = Lista.SelectedItem.ToString().Split(", ");
                gabiLista.Items.Add(adatok[0]);
            }
        }
        private void Mate_Click(object sender, RoutedEventArgs e)
        {
            if (Lista.SelectedIndex != -1)
            {
                string[] adatok = Lista.SelectedItem.ToString().Split(", ");
                mateLista.Items.Add(adatok[0]);
            }
        }
    }
}